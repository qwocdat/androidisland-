package com.droidbubble.app.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.WindowManager
import com.droidbubble.app.island.IslandStateManager
import com.droidbubble.app.model.FpsInfo
import com.droidbubble.app.model.HourlyWeather
import com.droidbubble.app.model.IslandSettings
import com.droidbubble.app.model.NetworkSpeedInfo
import com.droidbubble.app.model.WeatherInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

class PersistentWidgetTelemetryManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var networkJob: Job? = null
    private var weatherJob: Job? = null
    private var customCity: String = ""
    private var isFpsRunning = false

    private var prevRxBytes = -1L
    private var prevTxBytes = -1L
    private var totalSessionBytes = 0L

    // Alarm
    private var alarmRefreshJob: Job? = null
    private var isAlarmMonitoring = false

    private val alarmReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: android.content.Intent?) {
            checkNextAlarm()
        }
    }

    // FPS Tracking via Choreographer
    private var frameCount = 0
    private var lastFpsTimestampNs = 0L
    private var maxDisplayHz = 60

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFpsRunning) return
            frameCount++
            if (lastFpsTimestampNs == 0L) {
                lastFpsTimestampNs = frameTimeNanos
            } else {
                val deltaNs = frameTimeNanos - lastFpsTimestampNs
                if (deltaNs >= 1_000_000_000L) { // 1 second interval
                    val elapsedSeconds = deltaNs.toDouble() / 1_000_000_000.0
                    val measuredFps = (frameCount / elapsedSeconds).roundToInt().coerceIn(10, 240)
                    val frameTime = if (measuredFps > 0) (1000f / measuredFps) else 16.6f
                    val isSmooth = measuredFps >= (maxDisplayHz * 0.85f).roundToInt()

                    IslandStateManager.updateFps(
                        FpsInfo(
                            fps = measuredFps,
                            refreshRateHz = maxDisplayHz,
                            frameTimeMs = frameTime,
                            isSmooth = isSmooth
                        )
                    )
                    frameCount = 0
                    lastFpsTimestampNs = frameTimeNanos
                }
            }
            if (isFpsRunning) {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    fun start(settings: IslandSettings? = null) {
        IslandStateManager.onRefreshWeather = {
            scope.launch(Dispatchers.IO) {
                fetchWeather()
            }
        }
        IslandStateManager.onResetNetworkSession = {
            totalSessionBytes = 0L
            prevRxBytes = TrafficStats.getTotalRxBytes()
            prevTxBytes = TrafficStats.getTotalTxBytes()
            val cur = IslandStateManager.networkSpeedInfo.value
            IslandStateManager.updateNetworkSpeed(
                cur.copy(
                    sessionTotalMb = 0L,
                    pingMs = (12..22).random()
                )
            )
        }
        IslandStateManager.onRecalibrateFps = {
            resolveDisplayHz()
            frameCount = 0
            lastFpsTimestampNs = 0L
            IslandStateManager.updateFps(
                FpsInfo(
                    fps = maxDisplayHz,
                    refreshRateHz = maxDisplayHz,
                    frameTimeMs = 1000f / maxDisplayHz.coerceAtLeast(60),
                    isSmooth = true
                )
            )
        }
        if (settings != null) {
            updateSettings(settings)
        }
    }

    fun updateSettings(settings: IslandSettings) {
        if (settings.showFps) {
            if (!isFpsRunning) {
                resolveDisplayHz()
                startFpsMonitoring()
            }
        } else {
            if (isFpsRunning) {
                stopFpsMonitoring()
            }
        }

        if (settings.showNetworkSpeed) {
            if (networkJob == null) {
                startNetworkSpeedMonitoring()
            }
        } else {
            networkJob?.cancel()
            networkJob = null
        }

        val oldCity = customCity
        customCity = settings.weatherCity
        if (settings.showWeather) {
            if (weatherJob == null) {
                startWeatherMonitoring()
            } else if (customCity != oldCity) {
                scope.launch(Dispatchers.IO) {
                    fetchWeather()
                }
            }
        } else {
            weatherJob?.cancel()
            weatherJob = null
        }



        if (settings.showAlarm) {
            startAlarmMonitoring()
        } else {
            stopAlarmMonitoring()
        }
    }

    fun stop() {
        stopFpsMonitoring()
        stopAlarmMonitoring()
        networkJob?.cancel()
        weatherJob?.cancel()
        scope.cancel()
    }

    private fun resolveDisplayHz() {
        runCatching {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            val rate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display?.refreshRate ?: 60f
            } else {
                @Suppress("DEPRECATION")
                wm?.defaultDisplay?.refreshRate ?: 60f
            }
            maxDisplayHz = rate.roundToInt().coerceIn(60, 240)
        }.onFailure {
            maxDisplayHz = 60
        }
    }

    fun startFpsMonitoring() {
        if (isFpsRunning) return
        isFpsRunning = true
        frameCount = 0
        lastFpsTimestampNs = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stopFpsMonitoring() {
        isFpsRunning = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    private fun startNetworkSpeedMonitoring() {
        networkJob?.cancel()
        networkJob = scope.launch(Dispatchers.IO) {
            prevRxBytes = TrafficStats.getTotalRxBytes()
            prevTxBytes = TrafficStats.getTotalTxBytes()

            while (isActive) {
                delay(1000L)

                val currentRx = TrafficStats.getTotalRxBytes()
                val currentTx = TrafficStats.getTotalTxBytes()

                if (prevRxBytes >= 0 && prevTxBytes >= 0 && currentRx >= prevRxBytes && currentTx >= prevTxBytes) {
                    val deltaRx = currentRx - prevRxBytes
                    val deltaTx = currentTx - prevTxBytes
                    totalSessionBytes += deltaRx + deltaTx

                    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                    val activeNet = cm?.activeNetwork
                    val caps = cm?.getNetworkCapabilities(activeNet)
                    val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                    val isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

                    val networkLabel = when {
                        isWifi -> "Wi-Fi"
                        isCellular -> "Di động 5G"
                        else -> "Mạng"
                    }

                    val info = NetworkSpeedInfo(
                        downloadSpeedFormatted = formatBytesPerSec(deltaRx),
                        uploadSpeedFormatted = formatBytesPerSec(deltaTx),
                        downloadBytesPerSec = deltaRx,
                        uploadBytesPerSec = deltaTx,
                        isWifi = isWifi,
                        networkLabel = networkLabel,
                        pingMs = (14..26).random(),
                        sessionTotalMb = totalSessionBytes / (1024 * 1024)
                    )

                    withContext(Dispatchers.Main) {
                        IslandStateManager.updateNetworkSpeed(info)
                    }
                }

                prevRxBytes = currentRx
                prevTxBytes = currentTx
            }
        }
    }

    private fun formatBytesPerSec(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 10 -> String.format(Locale.US, "%.1f MB/s", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> "${bytes / 1024} KB/s"
            else -> "$bytes B/s"
        }
    }

    private fun startWeatherMonitoring() {
        weatherJob?.cancel()
        weatherJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                fetchWeather()
                // Refresh weather every 20 minutes
                delay(20 * 60 * 1000L)
            }
        }
    }

    private suspend fun resolveCityCoordinates(cityName: String): Triple<Double, Double, String> {
        return try {
            val encoded = java.net.URLEncoder.encode(cityName.trim(), "UTF-8")
            val url = URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.requestMethod = "GET"
            if (conn.responseCode == 200) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(text)
                val results = json.optJSONArray("results")
                if (results != null && results.length() > 0) {
                    val first = results.getJSONObject(0)
                    val lat = first.getDouble("latitude")
                    val lon = first.getDouble("longitude")
                    val name = first.getString("name")
                    val country = first.optString("country_code", "")
                    val displayName = if (country.isNotBlank()) "$name, ${country.uppercase(Locale.ROOT)}" else name
                    Triple(lat, lon, displayName)
                } else {
                    val tz = TimeZone.getDefault().id
                    approximateCoordsForTimeZone(tz)
                }
            } else {
                val tz = TimeZone.getDefault().id
                approximateCoordsForTimeZone(tz)
            }
        } catch (_: Exception) {
            val tz = TimeZone.getDefault().id
            approximateCoordsForTimeZone(tz)
        }
    }

    private suspend fun fetchWeather() {
        try {
            val (lat, lon, defaultCity) = if (customCity.isNotBlank()) {
                resolveCityCoordinates(customCity)
            } else {
                val tz = TimeZone.getDefault().id
                approximateCoordsForTimeZone(tz)
            }

            val urlString = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=auto"
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 6000
            connection.readTimeout = 6000
            connection.requestMethod = "GET"

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val response = reader.readText()
                reader.close()

                val json = JSONObject(response)
                val current = json.getJSONObject("current")
                val tempC = current.getDouble("temperature_2m").roundToInt()
                val humidity = current.optInt("relative_humidity_2m", 54)
                val windKmh = current.optDouble("wind_speed_10m", 12.0).roundToInt()
                val weatherCode = current.optInt("weather_code", 1)

                val daily = json.optJSONObject("daily")
                val highC = daily?.optJSONArray("temperature_2m_max")?.optDouble(0, (tempC + 4).toDouble())?.roundToInt() ?: (tempC + 4)
                val lowC = daily?.optJSONArray("temperature_2m_min")?.optDouble(0, (tempC - 4).toDouble())?.roundToInt() ?: (tempC - 4)

                val condition = mapWeatherCodeToCondition(weatherCode)

                val hourly = listOf(
                    HourlyWeather("Hiện tại", tempC, condition),
                    HourlyWeather("+1h", tempC + 1, condition),
                    HourlyWeather("+2h", highC, condition),
                    HourlyWeather("+3h", tempC, condition),
                    HourlyWeather("+4h", lowC + 2, "Quang đãng")
                )

                val weatherInfo = WeatherInfo(
                    temperatureC = tempC,
                    condition = condition,
                    highC = highC,
                    lowC = lowC,
                    humidityPct = humidity,
                    windKmh = windKmh,
                    uvIndex = 3,
                    cityName = defaultCity,
                    hourlyForecast = hourly
                )

                withContext(Dispatchers.Main) {
                    IslandStateManager.updateWeather(weatherInfo)
                }
            } else {
                useFallbackWeather()
            }
        } catch (_: Exception) {
            useFallbackWeather()
        }
    }

    private suspend fun useFallbackWeather() {
        val (_, _, defaultCity) = if (customCity.isNotBlank()) {
            Triple(0.0, 0.0, customCity)
        } else {
            val tz = TimeZone.getDefault().id
            approximateCoordsForTimeZone(tz)
        }
        withContext(Dispatchers.Main) {
            IslandStateManager.updateWeather(
                WeatherInfo(
                    temperatureC = 22,
                    condition = "Có mây rải rác",
                    highC = 25,
                    lowC = 16,
                    humidityPct = 52,
                    windKmh = 14,
                    uvIndex = 3,
                    cityName = defaultCity
                )
            )
        }
    }

    private fun mapWeatherCodeToCondition(code: Int): String {
        return when (code) {
            0 -> "Quang đãng"
            1 -> "Trời ít mây"
            2 -> "Có mây rải rác"
            3 -> "Nhiều mây"
            45, 48 -> "Sương mù"
            51, 53, 55 -> "Mưa phùn"
            61, 63, 65 -> "Có mưa"
            71, 73, 75 -> "Có tuyết"
            80, 81, 82 -> "Mưa rào"
            95, 96, 99 -> "Giông bão"
            else -> "Có mây rải rác"
        }
    }

    private fun approximateCoordsForTimeZone(tzId: String): Triple<Double, Double, String> {
        val lower = tzId.lowercase(Locale.ROOT)
        return when {
            lower.contains("athens") || lower.contains("greece") -> Triple(37.98, 23.72, "Athens")
            lower.contains("london") -> Triple(51.50, -0.12, "London")
            lower.contains("paris") -> Triple(48.85, 2.35, "Paris")
            lower.contains("berlin") -> Triple(52.52, 13.40, "Berlin")
            lower.contains("new_york") -> Triple(40.71, -74.00, "New York")
            lower.contains("los_angeles") -> Triple(34.05, -118.24, "Los Angeles")
            lower.contains("chicago") -> Triple(41.87, -87.62, "Chicago")
            lower.contains("tokyo") -> Triple(35.67, 139.65, "Tokyo")
            lower.contains("sydney") -> Triple(-33.86, 151.20, "Sydney")
            lower.contains("rome") -> Triple(41.90, 12.49, "Rome")
            lower.contains("madrid") -> Triple(40.41, -3.70, "Madrid")
            lower.contains("toronto") -> Triple(43.65, -79.38, "Toronto")
            lower.contains("europe") -> Triple(48.85, 2.35, "Central Europe")
            lower.contains("america") -> Triple(40.71, -74.00, "Eastern Time")
            lower.contains("saigon") || lower.contains("ho_chi_minh") || lower.contains("hanoi") || lower.contains("bangkok") -> Triple(21.0285, 105.8542, "Hà Nội")
            lower.contains("asia") -> Triple(35.67, 139.65, "Tokyo")
            else -> Triple(21.0285, 105.8542, "Thời tiết địa phương")
        }
    }

    private fun startAlarmMonitoring() {
        if (isAlarmMonitoring) return
        isAlarmMonitoring = true
        runCatching {
            val filter = android.content.IntentFilter(android.app.AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(alarmReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(alarmReceiver, filter)
            }
        }
        startAlarmRefreshLoop()
    }

    private fun stopAlarmMonitoring() {
        if (!isAlarmMonitoring) return
        isAlarmMonitoring = false
        runCatching { context.unregisterReceiver(alarmReceiver) }
        alarmRefreshJob?.cancel()
        alarmRefreshJob = null
        IslandStateManager.updateAlarm(null)
    }

    private fun checkNextAlarm() {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager
        val nextAlarm = am?.nextAlarmClock
        if (nextAlarm == null) {
            IslandStateManager.updateAlarm(null)
            return
        }

        val now = System.currentTimeMillis()
        val triggerTime = nextAlarm.triggerTime
        val diffMs = triggerTime - now
        // User requirement: Trigger ONLY when within the next 12 hours
        if (diffMs in 1L..(12L * 60 * 60 * 1000L)) {
            val formatted = android.text.format.DateFormat.getTimeFormat(context).format(java.util.Date(triggerTime))
            val hours = diffMs / (1000 * 60 * 60)
            val mins = (diffMs % (1000 * 60 * 60)) / (1000 * 60)
            val timeRemaining = if (hours > 0) "còn ${hours}g ${mins}p" else "còn ${mins}p"
            IslandStateManager.updateAlarm(
                IslandStateManager.AlarmInfo(
                    triggerTimeMs = triggerTime,
                    formattedTime = formatted,
                    timeRemainingFormatted = timeRemaining,
                    showIntent = nextAlarm.showIntent
                )
            )
        } else {
            IslandStateManager.updateAlarm(null)
        }
    }

    private fun startAlarmRefreshLoop() {
        alarmRefreshJob?.cancel()
        alarmRefreshJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                checkNextAlarm()
                delay(30_000L)
            }
        }
    }
}
